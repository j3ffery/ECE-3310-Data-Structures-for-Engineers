#pragma once
#pragma once
class Node
{
public:
	int data;
	Node* next;
	Node* prev;
	Node(int d);
};