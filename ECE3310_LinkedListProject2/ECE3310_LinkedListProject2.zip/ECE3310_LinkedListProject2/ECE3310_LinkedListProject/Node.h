#pragma once

class Node
{
public:
	int coe;
	int exp;
	Node* next;
	Node* prev;
	Node(int c, int e);
};