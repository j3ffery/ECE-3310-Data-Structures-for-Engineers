#pragma once
#include <string>

struct Poly
{
	int exp;
	int coe;
};
